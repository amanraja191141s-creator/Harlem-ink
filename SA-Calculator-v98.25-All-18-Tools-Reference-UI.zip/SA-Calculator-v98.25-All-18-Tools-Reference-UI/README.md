# SA Calculator v98.25 — All 18 Tools Reference UI

- App version: `1.98.25-v98.25`
- Android versionCode: `1098025`
- Design: consistent midnight navy surfaces, bright blue actions, green result cards, compact tool forms and four-tab navigation across all 18 destinations (Calculator + 17 tools).
- Existing calculation IDs, calculation handlers, currency refresh logic, favorites, settings, history and scientific functions are preserved.
- Responsive finishing: compact widths, short landscape screens, bounded scrolling, keyboard resize metadata and safe-area-aware controls.
- Cache identity: `sa-calculator-v98-25-all-tools-reference-ui`.

## GitHub upload

1. Extract this ZIP and upload the **contents** of the extracted project folder to the repository root (so `package.json` is at repository root), or upload this complete ZIP to repository root.
2. Replace `.github/workflows/main.yml` with the matching `main-v98.25-all-18-tools.yml` file supplied alongside the ZIP (the ZIP also contains the exact workflow).
3. Commit and run the single active `SA Calculator v98.25 - All 18 Tools Reference UI Android APK` workflow.
4. Download artifact `SA-Calculator-Debug-APK-1.98.25-v98.25`.
5. Install it and verify Settings → About & Support reports `v1.98.25-v98.25`.

## Local checks

```sh
npm test
npm run build:web
```

GitHub Actions performs the Android SDK/Gradle APK build and APK identity/checksum verification. A successful local web test is not proof of a successful remote APK build. Physical Android screenshot/touch QA is still required before claiming device-perfect rendering or zero defects.
