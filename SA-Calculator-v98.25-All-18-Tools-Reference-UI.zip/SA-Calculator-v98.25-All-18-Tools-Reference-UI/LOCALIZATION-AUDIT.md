# SA Calculator v1.94.0-v94 — localization rebuild audit

## Scope inspected

The v1.92.8 source ZIP was reopened and the localization system, HTML, application JavaScript, styles, service worker, manifest, and existing tests were inspected. This release expands the localization layer rather than claiming that a phrase count alone proves complete coverage.

## Changes in v1.94.0

- Expanded the shared translation catalogue to **628 keys**, with seven non-English translations per key (**4,396 translated values**).
- Added a source inventory for **400 static HTML text and accessibility/placeholder strings**. The inventory has zero unaccounted ordinary-language strings; brand names, language self-names, mathematical notation, formulas, and generated numeric examples are explicitly preserved.
- Added translation coverage for all **76 Unit Converter unit labels**, retaining canonical symbols and abbreviations.
- Added bundled Unicode CLDR-derived display-name fallback data for the **105 selectable currencies in all eight app languages** (English, Hindi, Urdu, Spanish, French, German, Arabic, Chinese). The runtime `Intl.DisplayNames` path remains preferred; bundled data covers older WebViews without that API.
- Expanded dynamic localization for calculator values/results, live preview, memory, angle mode, currency-pair accessibility labels, unit labels, currency rate status, date countdowns, history, loan schedule, unit-price comparison, startup screen, validation and toast messages.
- Added plural-aware date countdowns using `Intl.PluralRules`, and locale-aware digit/group/decimal formatting using `Intl.NumberFormat`.
- Input and textarea placeholders are localized without rewriting user-entered values. Text inputs use `dir="auto"`; numeric/expression inputs remain LTR.
- Arabic and Urdu set document-level `lang`/`dir` and receive RTL drawer/layout handling; calculator expressions and keypad remain LTR to preserve mathematical reading order.
- Unit option source labels are retained separately so switching languages repeatedly does not translate an already translated value.
- Added the bundled currency-name asset to the service-worker precache and bumped the cache namespace to v1.94.0.

## Automated verification

- **90/90 automated tests passed** (`npm test`).
- JavaScript syntax checks passed for `app.js`, `localization.js`, `currency-localized-names.js`, and the release tests.
- The test suite checks the merged 628-key catalogue across all seven translated languages, all 400 inventoried static strings/attributes, all 76 unit labels, all 105 currency names across eight locales, plural behavior, locale formatting, dynamic placeholders, currency refresh behavior, and existing calculator regressions.
- HTTP smoke check returned `200 OK` for the app server.
- ZIP integrity and release contents are checked separately before packaging.

## Known limitations / release gates

- Translations are model-authored and CLDR-derived, not independently certified by native-speaking reviewers. Legal, financial, health, and high-impact explanatory wording should receive native-speaker review before a public production release.
- Browser-based visual testing could not be completed in this environment because the browser runtime blocked local navigation. Android/Acode WebView testing on physical devices remains required, especially for Arabic/Urdu overflow, text shaping, keypad placement, and older WebView Intl support.
- The static inventory covers the current HTML text/attributes and explicit dynamic message templates. It cannot prove that every future or server-provided string will be localized; new UI strings must be added to the inventory and catalogue.
- Proper names, provider names, currency codes, unit symbols, mathematical expressions, user-entered text, and city/time-zone proper names are intentionally not translated.
- “Lag-free” and “bug-free” cannot be guaranteed from automated tests alone. No performance guarantee is claimed.

## Files added/changed

- `assets/js/localization.js`
- `assets/js/currency-localized-names.js` (new)
- `assets/js/app.js`
- `assets/css/app.css`
- `index.html`
- `service-worker.js`
- `tests/localization-inventory.json` (new)
- `tests/unit-localization-inventory.json` (new)
- `tests/release-gate.test.js`

## Release decision

v1.94.0 is a materially more complete localization development build. Do not describe it as native-speaker-certified or fully device-verified until the remaining manual review gates above are completed.
