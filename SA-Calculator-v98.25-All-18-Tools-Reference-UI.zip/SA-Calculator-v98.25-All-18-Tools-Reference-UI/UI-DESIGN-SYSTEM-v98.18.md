# SA Calculator v98.19 — Premium Reference UI

The user's 18-tool poster is treated as a visual language reference, not a literal miniature phone layout.

- Outer/app environment: pure black surround and deep midnight-navy app shell.
- Brand: existing SA metallic-blue/gold app mark, compact brand header, white/cyan title and premium tagline.
- Tool title strips: deep royal-blue gradient with cyan divider and gold crown accent.
- Form cards: ice-blue/white surfaces, cyan/electric-blue illuminated borders, rounded corners.
- Inputs: white fields, dark navy text, visible focus rings and touch-friendly height.
- Results: vivid green semantic result cards with bold dark figures.
- Actions: electric-blue/cyan gradient buttons; gold reserved for equals and small highlights.
- Navigation, history, settings, scientific panel, currency picker and dialogs share the same navy/blue surface language.
- Responsive phone, narrow phone, landscape, tablet, high-contrast and reduced-motion rules are retained.

The v98.19 release locks the visual identity to Premium Dark + Premium Blue so a legacy saved Light/Pink preference cannot silently restore the old appearance.
