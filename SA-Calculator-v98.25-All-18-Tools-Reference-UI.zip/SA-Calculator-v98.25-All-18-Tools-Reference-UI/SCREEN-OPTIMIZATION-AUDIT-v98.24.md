# SA Calculator v98.24 — Screen optimization and system audit

## Source inspected
- Exact baseline: `SA-Calculator-v98.23-Reference-UI-Release-Lock.zip`.
- The baseline source's own v98.23 verification report says the GitHub Android Gradle build and physical-device screenshot comparison were still pending.
- The supplied 2026-11-16 recording frame showed About → Version `v1.98.19-v98.19`; this is older than the available v98.23 source and cannot validate its UI.

## v98.24 changes
- Preserves the reference-native dark navy / blue action / green result visual system and all existing calculation modules.
- Adds a final responsive viewport layer with bounded dynamic-height sizing and `min-height:0` constraints for the app shell and active screen.
- Hardens vertical scroll regions to avoid scroll chaining and keep tool forms usable on compact screens.
- Adds a dedicated narrow-width layout at 340px and below.
- Adds a compact landscape layout for short-height devices so the calculator keypad and bottom navigation retain usable space.
- Adds `interactive-widget=resizes-content` to the viewport metadata for modern Android WebView keyboard resizing.
- Preserves reduced-motion behavior and existing safe-area padding rules.
- Advances package/runtime/HTML/PWA/cache/Android identity to `1.98.24-v98.24` and Android versionCode `1098024`.
- Keeps the two workflow copies and embedded workflow byte-identical.

## Regression coverage
- Existing baseline suite: 185 tests passed before edits.
- New v98.24 tests cover responsive viewport rules, narrow and landscape layouts, all 18 requested destinations, favorites/bottom navigation, keyboard viewport metadata, and release identity.
- JavaScript syntax, YAML parsing, web-bundle generation, and full regression suite are run as part of local verification.

## Explicit verification limits
- This environment cannot certify a physical Android phone's exact rendering, actual touch latency, or a GitHub-hosted Gradle APK build.
- No claim of zero bugs or pixel-perfect equivalence is made until the v98.24 APK is installed and checked on the target device at the actual display resolution and font scale.
