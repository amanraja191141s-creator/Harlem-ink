# SA Calculator v98.19 — Reference UI audit

## Reference-derived requirements
The supplied Android reference shows a native-style dark calculator application, not a neon promotional dashboard. The visual system is:
- Deep navy/near-black app background and compact dark toolbar.
- Small blue calculator brand tile and clear screen title.
- Calculator display in a separate inset rounded dark panel.
- Rounded dark number keys with bright blue operator/action keys.
- Dedicated tool screens with compact title bars and dark form cards.
- Dark input surfaces with legible light text and restrained blue focus borders.
- Bright blue primary Calculate/Convert buttons.
- Green semantic result panels with green values and icons.
- Four-item bottom navigation: Calculator, Tools, Favorites, Settings.
- Slide-out tool navigation, responsive layouts, and Android safe-area support.

## Source inspection findings
- The v98.18 source still used the previous poster/neon treatment: bright cyan borders, white/ice-blue form cards, cyan circular operators, crown decoration and no persistent four-tab bottom navigation.
- The original app already contained 18 core destinations (17 calculator/converter destinations plus Settings), working screen switching, favorites storage, calculator engines, currency logic, tool calculations and settings.
- Favorites had a settings manager and drawer section but no dedicated bottom-tab destination.
- The v98.19 update changes presentation and navigation while preserving the existing calculation functions and currency provider logic.

## v98.19 changes
- Replaced the prior neon/ice-blue appearance with a restrained native dark navy design system.
- Added persistent bottom navigation for Calculator, Tools, Favorites and Settings.
- Added a Favorites destination populated from the user's existing saved favorites; tapping a favorite opens its existing calculator screen.
- Tools tab opens the existing drawer; on a tool screen the header's left control returns to Calculator.
- Updated calculator keypad, display, tool cards, fields, action buttons, result panels, drawer, dialogs and settings surfaces to match the reference.
- Preserved responsive layout, focus states, reduced-motion behavior and safe-area insets.
- Bumped package/app/manifest and service-worker cache identity to v98.19.

## Verification limits
The source regression suite, JS parsing, CSS parsing, YAML parsing and Android web bundle staging were verified locally. A GitHub-hosted Gradle APK build and physical Android installation/visual test are still required. No claim of zero bugs on every device is made before those checks.
