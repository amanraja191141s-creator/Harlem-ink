# Build verification — SA Calculator v98.24

## Verified locally
- Source package identity: `1.98.24-v98.24`.
- Android versionCode derived by the native patch script: `1098024`.
- Node regression suite: **189 passed, 0 failed**.
- JavaScript syntax checks: passed for app, localization, currency names, theme bootstrap, server, service worker and both Android scripts.
- Android web bundle preparation: passed; required runtime assets copied to `www/`.
- Workflow YAML parse: passed.
- Workflow parity: root `android-apk.yml` is byte-identical to `.github/workflows/main.yml`.
- Active GitHub Actions workflow count: one; duplicate `.github/workflows/android-apk.yml` removed to prevent duplicate/confusing APK runs.
- Responsive regression coverage added for 340px-and-under screens, short landscape screens, dynamic viewport bounds, scroll containment, keyboard resize metadata and all 18 tool destinations.

## Not run / must still be verified
- Android Gradle APK build was not run in this local environment because the Android SDK/Gradle runner is not configured here.
- No physical Android device installation or pixel comparison was performed here.
- The supplied 2026-11-16 recording showed About version `v1.98.19-v98.19`, so that recording does not validate the v98.23/v98.24 source.
- Do not describe the app as guaranteed bug-free or pixel-perfect until the v98.24 artifact is installed and tested on the target phone.
