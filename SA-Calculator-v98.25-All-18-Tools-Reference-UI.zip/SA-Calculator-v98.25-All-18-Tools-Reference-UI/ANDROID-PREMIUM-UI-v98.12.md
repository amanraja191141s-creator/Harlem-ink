# SA Calculator v98.12 — Android premium UI repair

## Source changes
- Replaced the launcher artwork with the new SA metallic/cyan/gold premium icon.
- Added density-specific Android launcher icon resources and adaptive icon definitions.
- Added a deterministic post-Capacitor-sync script to copy the launcher icon into the generated Android project and patch generated AppTheme styles for a dark, high-contrast status/navigation bar.
- Added safe-area-aware viewport padding and a final responsive premium design layer for cards, controls, keypad, dialogs, and all calculator screens.
- Refined the Currency Converter layout, amount fields, swap control, status/refresh metadata, and narrow/short-screen behavior.
- Removed contradictory `data-readonly=true` from the destination amount field; the converter intentionally supports editing either side and reverse calculation.
- Updated app/theme/cache version to v98.12.

## Source verification
- `node --test tests/*.test.js`: run in this build environment after changes.
- `npm run build:web`: run after changes.
- Android Gradle/APK build must run in GitHub Actions; this environment does not have the generated Android project/Gradle wrapper.

## Important limitation
The conversation contains the v98.11 source ZIP but no `app-debug.apk` attachment. This is a source-level repair and rebuild preparation, not a direct binary patch or device audit of the downloaded APK. Upload the exact APK and device screenshots/logcat to diagnose APK-specific/runtime-only issues.
