# SA Calculator v98.15 — complete premium tool-screen redesign

## Implemented design direction
The legacy light/grey tool appearance is visually superseded by one consistent deep-navy, electric-blue, cyan and restrained-gold system. The existing metallic silver/electric-blue/gold SA artwork remains the single brand source. The redesign is implemented in the main stylesheet and copied into the Android web bundle by `npm run build:web`.

## Shared components
- Deep navy app frame, header, screen canvas and navigation drawer.
- Bright, high-contrast form cards with readable dark labels and white editable fields.
- Blue/cyan primary actions, visible focus rings, clear selected states and tabular numeric values.
- Consistent 18–23px card corners, 13–15px control corners and 43–50px touch targets.
- Reworked history, scientific functions, currency picker, drawer, keypad sheets and settings overlays.
- Compact-phone, landscape and tablet breakpoints; reduced-motion, high-contrast and forced-colors support retained.

## Screen-by-screen
1. Calculator: dark expression/result hero, gold primary result, cyan preview and tactile four-column keypad.
2. Currency Converter: paired editable amount cards, prominent swap control and dated-rate status surface.
3. Units: readable source/destination selectors and strong converted result.
4. Discount: aligned amount/discount inputs and distinct savings/final-price hierarchy.
5. Percent: segmented mode selector and prominent calculated result.
6. Sales Tax: readable tax-rate and inclusion controls with emphasized total.
7. Body Metrics: balanced metric cards and distinct health-metric output.
8. Date: dark empty state, clear event cards and elevated event dialog.
9. Fuel Cost: grouped trip/fuel inputs and highlighted total cost.
10. Fuel Efficiency: aligned distance/fuel inputs and prominent efficiency output.
11. Grade Average: clean course rows and high-contrast average summary.
12. Number Base: four aligned base rows with tabular values.
13. Loan/EMI: grouped loan inputs, summary hierarchy and horizontally scrollable amortization table.
14. Savings: grouped contribution/term/rate fields and highlighted maturity balance.
15. Tip: clear bill/tip/tax inputs and restrained gold emphasis.
16. Unit Price: comparison rows and highlighted best-value result.
17. World Time: dark hero clock with searchable city/time-zone cards.
18. Settings: grouped preference cards, readable descriptions and accessible controls.

## Functional preservation
No calculator formulas, currency-rate math, data persistence, tool routing, field order or event handlers were intentionally changed. Only the application release identifier was advanced to `1.98.15-v98.15`. Existing app icon assets and Android launcher resource artwork are retained and used consistently.

## Verification
- `npm test`: **160 passed, 0 failed, 0 skipped**.
- `node --check assets/js/app.js`: passed.
- `node --check scripts/prepare-android-web.mjs`: passed.
- `node --check scripts/patch-android-native.mjs`: passed.
- `npm run build:web`: passed.
- Root and generated `www/` HTML, CSS and app JS copies compare identical.
- ZIP integrity checked after packaging.

## Device QA not yet claimed
This source-level pass does not prove that the generated APK has been installed and visually checked on physical Android hardware. Validate on the target Vivo device, including status/navigation bars, cutouts, keyboard overlap, launcher/splash artwork, all 18 tools, portrait/landscape, currency network/offline states and small-screen overflow.
